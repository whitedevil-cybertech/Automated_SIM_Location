"""Services Package."""

from backend.app.services.base import BaseService

__all__ = ["BaseService"]
